package com.example.demo.logging;

import com.lightstreamer.log.Logger;
import org.springframework.stereotype.Component;

@Component
public class LightstreamerLogger {

    private final Logger logger = Logger.getLogger("LightstreamerLogger");

    public void log(String message) {
        logger.info(message);
    }
}
